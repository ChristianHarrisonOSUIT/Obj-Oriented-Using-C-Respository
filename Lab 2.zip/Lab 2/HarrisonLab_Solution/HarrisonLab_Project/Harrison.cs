namespace HarrisonLab_Project
{
    public partial class Harrison : Form
    {
        public Harrison()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = Color.Red;
            lblTheDominator.ForeColor = Color.Red;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = Color.Blue;
            lblTheDominator.ForeColor = Color.Blue;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = Color.Yellow;
            lblTheDominator.ForeColor = Color.Yellow;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = Color.Lime;
            lblTheDominator.ForeColor = Color.Lime;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = Color.Orange;
            lblTheDominator.ForeColor = Color.Orange;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = Color.DarkViolet;
            lblTheDominator.ForeColor = Color.DarkViolet;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = Color.Cyan;
            lblTheDominator.ForeColor = Color.Cyan;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = Color.Pink;
            lblTheDominator.ForeColor = Color.Pink;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = Color.SaddleBrown;
            lblTheDominator.ForeColor = Color.SaddleBrown;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            lblTheDominator.Text = "1";
            lblTheDominator.ForeColor = Color.Black;
        }

        private void lblTheDominator_Click(object sender, EventArgs e)
        {
            AutoSize = false;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            lblTheDominator.Text = "2";
            lblTheDominator.ForeColor = Color.Black;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            lblTheDominator.Text = "3";
            lblTheDominator.ForeColor = Color.Black;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            lblTheDominator.Text = "4";
            lblTheDominator.ForeColor = Color.Black;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            lblTheDominator.Text = "5";
            lblTheDominator.ForeColor = Color.Black;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            lblTheDominator.Text = "6";
            lblTheDominator.ForeColor = Color.Black;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            lblTheDominator.Text = "7";
            lblTheDominator.ForeColor = Color.Black;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            lblTheDominator.Text = "8";
            lblTheDominator.ForeColor = Color.Black;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            lblTheDominator.Text = "9";
            lblTheDominator.ForeColor = Color.Black;
        }

        private void button19_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = Color.White;
            lblTheDominator.ForeColor = Color.White;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}