﻿namespace FormTeletypeLab1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            q = new Button();
            w = new Button();
            e = new Button();
            r = new Button();
            t = new Button();
            y = new Button();
            u = new Button();
            i = new Button();
            o = new Button();
            p = new Button();
            a = new Button();
            s = new Button();
            d = new Button();
            f = new Button();
            g = new Button();
            h = new Button();
            j = new Button();
            k = new Button();
            l = new Button();
            z = new Button();
            x = new Button();
            c = new Button();
            v = new Button();
            b = new Button();
            n = new Button();
            m = new Button();
            One = new Button();
            Two = new Button();
            Three = new Button();
            Four = new Button();
            Five = new Button();
            Six = new Button();
            Seven = new Button();
            Eight = new Button();
            Nine = new Button();
            Zero = new Button();
            Space = new Button();
            Period = new Button();
            Clear = new Button();
            Send = new Button();
            textBox1 = new TextBox();
            Exit = new Button();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // q
            // 
            q.BackColor = SystemColors.ActiveCaption;
            q.Location = new Point(340, 307);
            q.Name = "q";
            q.Size = new Size(23, 27);
            q.TabIndex = 0;
            q.Text = "q";
            q.UseVisualStyleBackColor = false;
            q.Click += q_Click;
            // 
            // w
            // 
            w.BackColor = SystemColors.ActiveCaption;
            w.Location = new Point(367, 307);
            w.Name = "w";
            w.Size = new Size(23, 27);
            w.TabIndex = 1;
            w.Text = "w";
            w.UseVisualStyleBackColor = false;
            w.Click += button2_Click;
            // 
            // e
            // 
            e.BackColor = SystemColors.ActiveCaption;
            e.Location = new Point(394, 307);
            e.Name = "e";
            e.Size = new Size(23, 27);
            e.TabIndex = 2;
            e.Text = "e";
            e.UseVisualStyleBackColor = false;
            e.Click += e_Click;
            // 
            // r
            // 
            r.BackColor = SystemColors.ActiveCaption;
            r.Location = new Point(421, 307);
            r.Name = "r";
            r.Size = new Size(23, 27);
            r.TabIndex = 3;
            r.Text = "r";
            r.UseVisualStyleBackColor = false;
            r.Click += r_Click;
            // 
            // t
            // 
            t.BackColor = SystemColors.ActiveCaption;
            t.Location = new Point(448, 307);
            t.Name = "t";
            t.Size = new Size(23, 27);
            t.TabIndex = 4;
            t.Text = "t";
            t.UseVisualStyleBackColor = false;
            t.Click += t_Click;
            // 
            // y
            // 
            y.BackColor = SystemColors.ActiveCaption;
            y.Location = new Point(475, 307);
            y.Name = "y";
            y.Size = new Size(23, 27);
            y.TabIndex = 5;
            y.Text = "y";
            y.UseVisualStyleBackColor = false;
            y.Click += y_Click;
            // 
            // u
            // 
            u.BackColor = SystemColors.ActiveCaption;
            u.Location = new Point(502, 307);
            u.Name = "u";
            u.Size = new Size(23, 27);
            u.TabIndex = 6;
            u.Text = "u";
            u.UseVisualStyleBackColor = false;
            u.Click += u_Click;
            // 
            // i
            // 
            i.BackColor = SystemColors.ActiveCaption;
            i.Location = new Point(529, 307);
            i.Name = "i";
            i.Size = new Size(23, 27);
            i.TabIndex = 7;
            i.Text = "i";
            i.UseVisualStyleBackColor = false;
            i.Click += i_Click;
            // 
            // o
            // 
            o.BackColor = SystemColors.ActiveCaption;
            o.Location = new Point(556, 307);
            o.Name = "o";
            o.Size = new Size(23, 27);
            o.TabIndex = 8;
            o.Text = "o";
            o.UseVisualStyleBackColor = false;
            o.Click += o_Click;
            // 
            // p
            // 
            p.BackColor = SystemColors.ActiveCaption;
            p.Location = new Point(583, 307);
            p.Name = "p";
            p.Size = new Size(23, 27);
            p.TabIndex = 9;
            p.Text = "p";
            p.UseVisualStyleBackColor = false;
            p.Click += p_Click;
            // 
            // a
            // 
            a.BackColor = SystemColors.ActiveCaption;
            a.Location = new Point(353, 340);
            a.Name = "a";
            a.Size = new Size(23, 27);
            a.TabIndex = 10;
            a.Text = "a";
            a.UseVisualStyleBackColor = false;
            a.Click += a_Click;
            // 
            // s
            // 
            s.BackColor = SystemColors.ActiveCaption;
            s.Location = new Point(380, 340);
            s.Name = "s";
            s.Size = new Size(23, 27);
            s.TabIndex = 11;
            s.Text = "s";
            s.UseVisualStyleBackColor = false;
            s.Click += s_Click;
            // 
            // d
            // 
            d.BackColor = SystemColors.ActiveCaption;
            d.Location = new Point(407, 340);
            d.Name = "d";
            d.Size = new Size(23, 27);
            d.TabIndex = 12;
            d.Text = "d";
            d.UseVisualStyleBackColor = false;
            d.Click += d_Click;
            // 
            // f
            // 
            f.BackColor = SystemColors.ActiveCaption;
            f.Location = new Point(434, 340);
            f.Name = "f";
            f.Size = new Size(23, 27);
            f.TabIndex = 13;
            f.Text = "f";
            f.UseVisualStyleBackColor = false;
            f.Click += f_Click;
            // 
            // g
            // 
            g.BackColor = SystemColors.ActiveCaption;
            g.Location = new Point(461, 340);
            g.Name = "g";
            g.Size = new Size(23, 27);
            g.TabIndex = 14;
            g.Text = "g";
            g.UseVisualStyleBackColor = false;
            g.Click += g_Click;
            // 
            // h
            // 
            h.BackColor = SystemColors.ActiveCaption;
            h.Location = new Point(488, 340);
            h.Name = "h";
            h.Size = new Size(23, 27);
            h.TabIndex = 15;
            h.Text = "h";
            h.UseVisualStyleBackColor = false;
            h.Click += h_Click;
            // 
            // j
            // 
            j.BackColor = SystemColors.ActiveCaption;
            j.Location = new Point(515, 340);
            j.Name = "j";
            j.Size = new Size(23, 27);
            j.TabIndex = 16;
            j.Text = "j";
            j.UseVisualStyleBackColor = false;
            j.Click += j_Click;
            // 
            // k
            // 
            k.BackColor = SystemColors.ActiveCaption;
            k.Location = new Point(542, 340);
            k.Name = "k";
            k.Size = new Size(23, 27);
            k.TabIndex = 17;
            k.Text = "k";
            k.UseVisualStyleBackColor = false;
            k.Click += k_Click;
            // 
            // l
            // 
            l.BackColor = SystemColors.ActiveCaption;
            l.Location = new Point(569, 340);
            l.Name = "l";
            l.Size = new Size(23, 27);
            l.TabIndex = 18;
            l.Text = "l";
            l.UseVisualStyleBackColor = false;
            l.Click += l_Click;
            // 
            // z
            // 
            z.BackColor = SystemColors.ActiveCaption;
            z.Location = new Point(380, 373);
            z.Name = "z";
            z.Size = new Size(23, 27);
            z.TabIndex = 19;
            z.Text = "z";
            z.UseVisualStyleBackColor = false;
            z.Click += z_Click;
            // 
            // x
            // 
            x.BackColor = SystemColors.ActiveCaption;
            x.Location = new Point(407, 373);
            x.Name = "x";
            x.Size = new Size(23, 27);
            x.TabIndex = 20;
            x.Text = "x";
            x.UseVisualStyleBackColor = false;
            x.Click += x_Click;
            // 
            // c
            // 
            c.BackColor = SystemColors.ActiveCaption;
            c.Location = new Point(434, 373);
            c.Name = "c";
            c.Size = new Size(23, 27);
            c.TabIndex = 21;
            c.Text = "c";
            c.UseVisualStyleBackColor = false;
            c.Click += c_Click;
            // 
            // v
            // 
            v.BackColor = SystemColors.ActiveCaption;
            v.Location = new Point(461, 373);
            v.Name = "v";
            v.Size = new Size(23, 27);
            v.TabIndex = 22;
            v.Text = "v";
            v.UseVisualStyleBackColor = false;
            v.Click += v_Click;
            // 
            // b
            // 
            b.BackColor = SystemColors.ActiveCaption;
            b.Location = new Point(488, 373);
            b.Name = "b";
            b.Size = new Size(23, 27);
            b.TabIndex = 23;
            b.Text = "b";
            b.UseVisualStyleBackColor = false;
            b.Click += b_Click;
            // 
            // n
            // 
            n.BackColor = SystemColors.ActiveCaption;
            n.Location = new Point(515, 373);
            n.Name = "n";
            n.Size = new Size(23, 27);
            n.TabIndex = 24;
            n.Text = "n";
            n.UseVisualStyleBackColor = false;
            n.Click += n_Click;
            // 
            // m
            // 
            m.BackColor = SystemColors.ActiveCaption;
            m.Location = new Point(542, 373);
            m.Name = "m";
            m.Size = new Size(23, 27);
            m.TabIndex = 25;
            m.Text = "m";
            m.UseVisualStyleBackColor = false;
            m.Click += m_Click;
            // 
            // One
            // 
            One.BackColor = SystemColors.ControlLightLight;
            One.Location = new Point(340, 274);
            One.Name = "One";
            One.Size = new Size(23, 27);
            One.TabIndex = 26;
            One.Text = "1";
            One.UseVisualStyleBackColor = false;
            One.Click += One_Click;
            // 
            // Two
            // 
            Two.BackColor = SystemColors.ControlLightLight;
            Two.Location = new Point(367, 274);
            Two.Name = "Two";
            Two.Size = new Size(23, 27);
            Two.TabIndex = 27;
            Two.Text = "2";
            Two.UseVisualStyleBackColor = false;
            Two.Click += Two_Click;
            // 
            // Three
            // 
            Three.BackColor = SystemColors.ControlLightLight;
            Three.Location = new Point(394, 274);
            Three.Name = "Three";
            Three.Size = new Size(23, 27);
            Three.TabIndex = 28;
            Three.Text = "3";
            Three.UseVisualStyleBackColor = false;
            Three.Click += Three_Click;
            // 
            // Four
            // 
            Four.BackColor = SystemColors.ControlLightLight;
            Four.Location = new Point(421, 274);
            Four.Name = "Four";
            Four.Size = new Size(23, 27);
            Four.TabIndex = 29;
            Four.Text = "4";
            Four.UseMnemonic = false;
            Four.UseVisualStyleBackColor = false;
            Four.Click += Four_Click;
            // 
            // Five
            // 
            Five.BackColor = SystemColors.ControlLightLight;
            Five.Location = new Point(448, 274);
            Five.Name = "Five";
            Five.Size = new Size(23, 27);
            Five.TabIndex = 30;
            Five.Text = "5";
            Five.UseVisualStyleBackColor = false;
            Five.Click += Five_Click;
            // 
            // Six
            // 
            Six.BackColor = SystemColors.ControlLightLight;
            Six.Location = new Point(475, 274);
            Six.Name = "Six";
            Six.Size = new Size(23, 27);
            Six.TabIndex = 31;
            Six.Text = "6";
            Six.UseVisualStyleBackColor = false;
            Six.Click += Six_Click;
            // 
            // Seven
            // 
            Seven.BackColor = SystemColors.ControlLightLight;
            Seven.Location = new Point(502, 274);
            Seven.Name = "Seven";
            Seven.Size = new Size(23, 27);
            Seven.TabIndex = 32;
            Seven.Text = "7";
            Seven.UseVisualStyleBackColor = false;
            Seven.Click += Seven_Click;
            // 
            // Eight
            // 
            Eight.BackColor = SystemColors.ControlLightLight;
            Eight.Location = new Point(529, 274);
            Eight.Name = "Eight";
            Eight.Size = new Size(23, 27);
            Eight.TabIndex = 33;
            Eight.Text = "8";
            Eight.UseVisualStyleBackColor = false;
            Eight.Click += Eight_Click;
            // 
            // Nine
            // 
            Nine.BackColor = SystemColors.ControlLightLight;
            Nine.Location = new Point(556, 274);
            Nine.Name = "Nine";
            Nine.Size = new Size(23, 27);
            Nine.TabIndex = 34;
            Nine.Text = "9";
            Nine.UseVisualStyleBackColor = false;
            Nine.Click += Nine_Click;
            // 
            // Zero
            // 
            Zero.BackColor = SystemColors.ControlLightLight;
            Zero.Location = new Point(583, 274);
            Zero.Name = "Zero";
            Zero.Size = new Size(23, 27);
            Zero.TabIndex = 35;
            Zero.Text = "0";
            Zero.UseVisualStyleBackColor = false;
            Zero.Click += Zero_Click;
            // 
            // Space
            // 
            Space.BackColor = Color.LightCoral;
            Space.Location = new Point(380, 405);
            Space.Name = "Space";
            Space.Size = new Size(145, 30);
            Space.TabIndex = 36;
            Space.Text = "Blank";
            Space.UseVisualStyleBackColor = false;
            Space.Click += Space_Click;
            // 
            // Period
            // 
            Period.BackColor = Color.LightCoral;
            Period.Location = new Point(542, 406);
            Period.Name = "Period";
            Period.Size = new Size(23, 27);
            Period.TabIndex = 37;
            Period.Text = ".";
            Period.UseVisualStyleBackColor = false;
            Period.Click += button1_Click;
            // 
            // Clear
            // 
            Clear.BackColor = Color.Gold;
            Clear.Location = new Point(631, 402);
            Clear.Name = "Clear";
            Clear.Size = new Size(86, 31);
            Clear.TabIndex = 38;
            Clear.Text = "Clear";
            Clear.UseVisualStyleBackColor = false;
            Clear.Click += Clear_Click;
            // 
            // Send
            // 
            Send.BackColor = Color.Gold;
            Send.Location = new Point(723, 403);
            Send.Name = "Send";
            Send.Size = new Size(84, 31);
            Send.TabIndex = 39;
            Send.Text = "Send";
            Send.UseVisualStyleBackColor = false;
            Send.Click += Send_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(124, 65);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(715, 201);
            textBox1.TabIndex = 40;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // Exit
            // 
            Exit.BackColor = Color.Gold;
            Exit.Location = new Point(813, 404);
            Exit.Name = "Exit";
            Exit.Size = new Size(78, 31);
            Exit.TabIndex = 41;
            Exit.Text = "Exit";
            Exit.UseVisualStyleBackColor = false;
            Exit.Click += Exit_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 420);
            label1.Name = "label1";
            label1.Size = new Size(0, 15);
            label1.TabIndex = 42;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(340, 9);
            label2.Name = "label2";
            label2.Size = new Size(272, 45);
            label2.TabIndex = 43;
            label2.Text = "TeleType Machine";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDarkDark;
            ClientSize = new Size(934, 450);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(Exit);
            Controls.Add(textBox1);
            Controls.Add(Send);
            Controls.Add(Clear);
            Controls.Add(Period);
            Controls.Add(Space);
            Controls.Add(Zero);
            Controls.Add(Nine);
            Controls.Add(Eight);
            Controls.Add(Seven);
            Controls.Add(Six);
            Controls.Add(Five);
            Controls.Add(Four);
            Controls.Add(Three);
            Controls.Add(Two);
            Controls.Add(One);
            Controls.Add(m);
            Controls.Add(n);
            Controls.Add(b);
            Controls.Add(v);
            Controls.Add(c);
            Controls.Add(x);
            Controls.Add(z);
            Controls.Add(l);
            Controls.Add(k);
            Controls.Add(j);
            Controls.Add(h);
            Controls.Add(g);
            Controls.Add(f);
            Controls.Add(d);
            Controls.Add(s);
            Controls.Add(a);
            Controls.Add(p);
            Controls.Add(o);
            Controls.Add(i);
            Controls.Add(u);
            Controls.Add(y);
            Controls.Add(t);
            Controls.Add(r);
            Controls.Add(e);
            Controls.Add(w);
            Controls.Add(q);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button q;
        private Button w;
        private Button e;
        private Button r;
        private Button t;
        private Button y;
        private Button u;
        private Button i;
        private Button o;
        private Button p;
        private Button a;
        private Button s;
        private Button d;
        private Button f;
        private Button g;
        private Button h;
        private Button j;
        private Button k;
        private Button l;
        private Button z;
        private Button x;
        private Button c;
        private Button v;
        private Button b;
        private Button n;
        private Button m;
        private Button One;
        private Button Two;
        private Button Three;
        private Button Four;
        private Button Five;
        private Button Six;
        private Button Seven;
        private Button Eight;
        private Button Nine;
        private Button Zero;
        private Button Space;
        private Button Period;
        private Button Clear;
        private Button Send;
        private TextBox textBox1;
        private Button Exit;
        private Label label1;
        private Label label2;
    }
}